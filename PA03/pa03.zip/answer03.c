#include "answer03.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*-----------------------String Concatenation-------------------------------*/

char * strcat_ex(char * * dest, int * n, const char *src) 

{

    char * buffer;

    if( (*dest == NULL) || (strlen(src) + strlen(*dest) + 1 > *n) ) //Is dest too small? 
    { 
    
       // If dest is null, don't include its lenght in buffer, revalue n

        if (*dest == NULL) 
            { 
            buffer =  malloc((sizeof(char)) * (1 + 2 * strlen(src)));
            *n = sizeof(char) * (1 + 2 * strlen(src) ); 
            free(*dest);     //Freeing dest's memory  
            *dest = buffer;  // Pointing dest to buffer
            strcpy(*dest, src);
            } 
                 
        else 
            { 
            buffer = malloc((sizeof(char)) * ( 1 + 2 * (strlen(*dest) + strlen(src))) );
            *n = sizeof(char) *  ( 1 + 2 * (strlen(*dest) + strlen(src)) );
            strcpy(buffer,*dest);
            free(*dest);     //Freeing dest's memory
            *dest = buffer;  // Pointing dest to buffer
             strcat (*dest, src);   //Concatenating src to dest
            }

    }
    
    else  //Dest is big enough for direct concatenation

    {
    strcat (* dest, src);
    }       
    
    return *dest;
}

/*---------------------------------EXPLODE-------------------------------*/

char * * explode(const char * str, const char * delims, int * arrLen)


{

    const char *s = str;
    int N = 0;
    char buffer[9000]; // temp[100];
    memcpy(buffer, s, (strlen(str) +1) * sizeof(char));
    s = buffer;

    while (*s != '\0')  // while pointer is not on null terminator
        {
        if ( strchr(delims, *s) != NULL) // If *s is in delims
            {
            N++;
            printf("%c\n", *s);
            }
        s++;
        } 

 
    printf("N = %d\n", N);   

    *arrLen = N + 1; // Number of strings is delimiters + 1
    
    char * * strArr = malloc ( sizeof(char * ) * (*arrLen) );    

    s = &str[0];
    
    int I = 0, J = 0, H = 0;
    int Previous = 0;
    int  Current = 0;
    int Counter = 0;
    
for( Counter = 0; Counter < *arrLen; Counter++)
    {
        while( (strchr(delims, *s) == NULL)  && (*s != '\0' ))
            {
            Current++;           //  Location of newest delim
            s++;
            }        

        I = Counter;
        strArr[I] = malloc ( sizeof(char) * (Current-Previous + 1) ); //maloc for string

        J = 0;
        for (H=Previous; H < Current; H++)  
            {
            strArr[I][J] = str[H];
            J++;
            }
    
        strArr[I][J] = ('\0'); // Adding null character
          
        printf(" strArr[%d] is %s\n", I, strArr[I] );
    ++Current;
    Previous = Current;
    s++;
    }


    

    return (strArr);
}

/*--------------------------------IMPLODE------------------------------*/

char * implode(char * * strArr, int len, const char * glue)

{
    int N=0, I =0;

    char * String = malloc ( (strlen(strArr[0])+1) * sizeof(char) );
    strcpy(String, strArr[0]);


    for (I=1; I < len; I++)
        {   
        String = strcat_ex(&String, &N, glue);
        String = strcat_ex(&String, &N, strArr[I]); 
       }
    
    return String;
    
}

/*----------------------------STRING SORTER------------------------------*/

void sortStringArray(char * * arrString, int len)

{
  //USE QSORT

    int cmpstring(const void *arg1, const void *arg2) // comparison function
        {
        const char * const * ptr1 = (const char * *) arg1;
        const char * const * ptr2 = (const char * *) arg2;
        const char * str1 = * ptr1;
        const char * str2 = * ptr2;
        return strcmp(str1,str2);
        }

    qsort(&arrString[0], len, sizeof(char *), cmpstring );



    
}

/*----------------------------------CHARACTER SORTER----------------------*/
void sortStringCharacters(char * str)

{

    int cmpcharacter(const void *arg1, const void *arg2) // comparison function
        {  
        return *(const char *) arg1 - *(const char *) arg2;
        }
 
    qsort(&str[0], (strlen(str)), sizeof(char), cmpcharacter );

}

/*-----------------------FREEING STRING ARRAY--------------*/

void destroyStringArray(char * * strArr, int len)

{

   
        int I = 0;
        while (I < len)
            {
            free(strArr[I]);
            I++;
            }
        free(strArr);
         

}
