
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "answer03.h"



void swapString(const char ** a, const char ** b)
{
    const char * tmp = *a;
    *a = *b;
    *b = tmp;
    printf("Calling swapString(...)\n");
    printf("&a = %p\n", &a);
    printf("&b = %p\n", &b);
    printf("&tmp = %p\n\n", &tmp);
    printf("**a = %d and **b = %d\n", **a, **b);
    
}

int main(int argc, char * * argv)
{
    

    printf("\nTesting swapString(...)\n");
    const char * str1 = "one";
    const char * str2 = "two";
    printf("Before swap, str1 == %p (i.e., '%s'), "
	   "str2 == %p (i.e., '%s')\n", str1, str1, str2, str2);
    swapString(&str1, &str2);
    printf("After swap, str1 == %p (i.e., '%s'), "
	   "str2 == %p (i.e., '%s')\n", str1, str1, str2, str2);



    printf("\n\n");

/*-----------------------------
    char * dest = "Hello";
    char * desty = NULL;
    const char * src = "There";
    const char * src2 = "what";
     int N = 6; 
    int *n;
    n = &N;


    strcat_ex(&dest,n, src);
    
    printf("%s", dest);

    free(dest);
 
    N = 0;
    strcat_ex(&desty,n,src2);

   printf("%s\n", desty);
 
    free(desty);


int len = 3;
    
char * * strArr = malloc(len * sizeof(char*));
   strArr[0] = strdup("The");
   strArr[1] = strdup("Turing test");
   strArr[2] = strdup("Yeah");
   const char * glue = "{newline}";
   char * str = implode(strArr, len, glue);
   // s is "The{newline}Turing test"

printf("%s\n", str);

free(strArr[0]);
free(strArr[1]);
free(strArr[2]);
free(strArr);

free(str);

---------------*/

    return EXIT_SUCCESS;
}


