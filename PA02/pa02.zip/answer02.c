



#include "answer02.h"

/*------------------------------Length Finder-----------------------*/
 
// Length of C string 'str', excluding the terminating null byte ('\0')


size_t my_strlen(const char * str) {

	int Count = 0, I=0;
        

	for(I=0;str[I] != '\0'; I++) 
            {
            ++Count;
            }
   
	return Count;

}


/*--------------Character Counter--------------------------*/

int my_countchar(const char * str, char ch) 
    {
    int I=0, Count =0;

    while (str[I] != '\0')
        {
            if (str[I] == ch)
               {
                   ++Count;
               }
        ++I;
        }
    return Count;
}

/*----------------Left Character Finder------------------*/

char * my_strchr(const char * str, int ch)

    {              
        int I=0;
        char * Character = NULL, * Ptr = str;               
        
        while((str[I] != '\0') & (str[I] != ch))
            {
            ++I;
 	    }
            
            if (str[I] == ch)
                {
                Character = Ptr;
                Character = Character + I;
                }

        return (char *) Character;        
    }    

/*-------------Right Character Finder-----------------------*/

char * my_strrchr(const char * str, int ch)

    { 

    int I = 0;
    char * Character = NULL, * Ptr = str, * Ptr1 = str;
             
     while(str[I] != '\0') 
            {
            ++I;
            }

    Ptr1 = Ptr1 + I;

    while ((I != 0) && (str[I] != ch))                  
            {   
            --I;
            }
    
            if (str[I] == ch)
                {
                Character = Ptr;
                Character = Character + I;
                }
        
        return (char *) Character;        
    }    

/*---------------------------------Finding Needle in Haystack-------------------------*/

char * my_strstr(const char * haystack, const char * needle)
    {              

    int I,J;
    I = 0;
    J = 0;
    char * Ptr = haystack;

    if (*needle == '\0') // If needle empty
            {
            return (char * ) haystack;
            }     
 
    else {

     while ((needle[0] != haystack[I])  && (haystack[I] != '\0'))  // Look for needle in haystack
      	{
        I++;
        }   

     if (( haystack[I] != '\0') || (needle[1] == '\0'))// If beginning of needle is in haystack
     
       {


            Ptr = Ptr + I; // Move pointer to beginning of needle in haystack
        
            while ((haystack[I] == needle[J]) && (needle[J] != '\0'))
                {
                I++;
                J++;
                }


 
          if ( needle[J] == '\0')    //If all of needle in haystack - return from beginning
                {
                return Ptr;
                }
         
            
        
            else

                {             //if needle not in haystack - return NULL
                Ptr = NULL;
                return Ptr;
                }


        }
    

     else        // if needle is not in haystack and not empty
            {
            Ptr = NULL;
            return Ptr;
            }
     
       } // closing else statement from very top

    }    

/*-------------------------------------String Copier---------------*/

char * my_strcpy(char * dest, const char * src)

    {              
    
    int I = 0;
 
    while (src[I] != '\0')
        {
        dest[I] = src[I];
        I++;
        }
    dest[I] = src[I];      //copying null byte character

    return (char *) dest;   
        
    }    




/*-------------------------String Concatenation------------------------*/

char * my_strcat(char * dest, const char * src)

    {

    int I, J;
    I=0;
    J=0;
    while (dest[I] != '\0' )
        {
        I++;
        }
    

    while (src[J] != '\0')
        {
        dest[I] = src[J];
        J++;
        I++;
        }

                
    dest[I] = '\0';    

       
    return (char *) dest;   
        
    }    

/*-----------------------------White Space Identifier-------------------------*/

int my_isspace(int ch)
    {     

    int A =0;

    if (( ch == ' ') || (ch == '\f') || (ch == '\n') || (ch == '\r') || (ch == '\t') || (ch == '\v'))
        {
        A = 1;
        }
             
    return A;   
        
    }    

/*--------------------------------------------Partial String to Integer Converter-----------------*/

int my_atoi(const char * str)

    { 
    int ret = 0, I = 0, J=0;

    while (( str[I] == ' ') || (str[I] == '\f') || (str[I] == '\n') || (str[I] == '\r') || (str[I] == '\t') || (str[I] == '\v'))
        {
        I++;          //check for whitespace
        }


    if (str[I] == '-')  // Check for negative sign
        {
        J =1;
        I++;
        }


    while ((str[I] >= '0') && (str[I] <= '9'))
        {
        ret = ret * 10;
        ret = ret + (str[I] - '0');
        I++;
        }
    
    if (J == 1)
        {
        return -ret;
        }
    
    else 
        {
        return ret;
        }

    }
