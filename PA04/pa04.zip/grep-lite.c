#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char * * argv)

{

    char buffer[2000];

/*--------------------------HELP STATEMENT---------------------------------*/

    int I = 1, HELPSTATEMENT = 0;    // Help statement identifier
    while( I < argc)
        {
        if (strcmp(argv[I], "--help") == 0) {
           printf("Search for PATTERN in standard input. PATTERN is a\nstring. grep-lite will search standard input line by\nline, and (by default) print out those lines which\ncontain pattern as a substring.\n\n-v, --invert-match     print non-matching lines\n-n, --line-number      print line numbers with output\n-q, --quiet            suppress all output\n\nExit status is 0 if any line is selected, 1 otherwise;\nif any error occurs, then the exit status is 2.");
           HELPSTATEMENT = 1;
           }
           
        I++;
         }
    if (HELPSTATEMENT ==1) { return EXIT_SUCCESS;}

/*---------------------------ERRONEOUS ARGUMENTS------------*/

    I = 1;
    
    while ( I < (argc-1) )    
        {
        if ( (strcmp(argv[I], "-q") !=0) && (strcmp(argv[I], "--quiet") !=0) && (strcmp(argv[I], "-n") !=0) && (strcmp(argv[I], "--line-number") !=0) && (strcmp(argv[I], "-v") != 0) && (strcmp(argv[I], "--invert-match") !=0))   
            {
            FILE * fp1 = stderr;
            strcpy(buffer, "Error with commandline arguments for grep-lite\n");
            fputs(buffer, fp1);
            fclose(fp1);
            return 2; 
            }
        I++;
        }

    if (argv[argc-1][0] == '-')
        {
        FILE * fp1 = stderr;
        strcpy(buffer, "Error with commandline arguments for grep-lite\n");
        fputs(buffer, fp1);
        fclose(fp1);
        return 2;   
        }

/*-----------------------COMMAND LINE ARGUMENT IDENTIFICATION--------------------*/


int Q = 0, N = 0, V = 0;
I = 1;

 while ( I < (argc-1) )
        {
        if ( (strcmp(argv[I], "-q") == 0 ) || (strcmp(argv[I], "--quiet") == 0))
            {
            Q = 1;
            }
        if ( (strcmp(argv[I], "-n") == 0 ) || (strcmp(argv[I], "--line-number") == 0))
            { 
            N = 1;
            }
         if ( (strcmp(argv[I], "-v") == 0 ) || (strcmp(argv[I], "--invert-match") == 0))
            { 
            V = 1;
            }
        I++;
        }

/*-----------------------------OUTPUTS-----------------------------*/
    int Matches = 0, LineCounter = 0;
    char * Search;
    FILE * fp = stdin;
    
    while (feof(fp) == 0)
        {
        fgets(buffer, 2000, fp);
        if (feof(fp) != 0) {break;}   
        LineCounter++;
        Search = strstr(buffer, argv[argc-1]); //argc-1 is last argument
        if (Search != NULL)                   // IF a match is found on line
            {
            Matches++;
            if (Q == 1) {return 0;}
            if (V == 1) {continue;}
            if (N == 1) {printf("%d:", LineCounter);}
            printf("%s", buffer);            
            }

        if (Search == NULL)                // IF a match is NOT found on line
            {
            if ( Q == 1) {continue;}
            if ( V == 1) 
                {
                if ( N == 1) {printf("%d:", LineCounter);}
                printf("%s", buffer);
                }
            }        

      }
    
    fclose(fp);

    if (Q ==1) { return 1;}

    return 0;
}
