#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char * * argv)

{

    char buffer[9000];

    if (argc==1) {  
        FILE * fp1 = stdin;
        FILE * fp2 = stdout;  
           while (feof(fp1) == 0)
                {
                fgets(buffer, 9000, fp1);
                if (feof(fp1) != 0) {break;}
                fputs(buffer, fp2);
                }
            fclose(fp1);
            fclose(fp2);
     return EXIT_SUCCESS;
         }
    
/*------------------------------HELP STATEMENT-----------------------------------------------*/
    int I = 1, HELPSTATEMENT = 0;    // Help statement identifier
    while( I < argc)
        {
        if (strcmp(argv[I], "--help") == 0) {       
           printf("Usage: cat-lite [--help] [FILE]...\nWith no FILE, or when FILE is -, read standard input.\n\nExamples:\ncat-lite README   Print the file README to standard output.\ncat-lite f - g    Print f's contents, then standard input,\n then g's contents.\ncat-lite          Copy standard input to standard output.\n");    
           HELPSTATEMENT = 1;
           }

        I++;
         }
    if (HELPSTATEMENT ==1) { return EXIT_SUCCESS;}

/*------------------------PRINTING FILES-------------------------*/

    I = 1;
    FILE * fp;
    while ( I < argc)  

        {
        

        if (strcmp( argv[I], "-" ) == 0 )
            {
              fp = stdin;
             while (feof(fp) == 0)
                {
                fgets(buffer, 9000, fp);
                if (feof(fp) != 0) {break;}
                printf("%s", buffer);
                }
            fclose(fp);
            I++;
            continue;
            }

        fp = fopen(argv[I], "r");

        if (fp == NULL)                               //Checks for erroneous filename 
            {                                         
            FILE * fp3 = stderr;
            strcpy(buffer, "cat cannot open ");
            strcat(buffer, argv[I]);
            fputs(buffer, fp3);
            fclose(fp3);  
            return EXIT_FAILURE;
            }


        if (strcmp( argv[I], "-" ) == 0 )
            {   
            fp = fopen("stdin", "r");
            while (feof(fp) == 0)
                {
                fgets(buffer, 9000, fp);
                if (feof(fp) != 0) {break;}
                printf("%s", buffer);
                }
            fclose(fp);
            I++;
            continue;
            }

            while (feof(fp) == 0)
                {
                fgets(buffer, 9000, fp); 
                if (feof(fp) != 0) {break;}     
                printf("%s", buffer);
                }
            fclose(fp);
        
          






        I++;
        }





    return EXIT_SUCCESS;
}
